<?php
session_start();

if(!isset($_SESSION['login'])) {
    header("location:login.php?pesan=logindulu");
}
include "koneksi.php";
$sql = "SELECT * FROM post ORDER BY no DESC";
$query = mysqli_query($koneksi, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>InstaKarya</title>
    <link rel="shortcut icon" href="images/a.png" type="image/x-icon">
    <link rel="stylesheet" href="css/bootstrap.min (9).css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
   
   <style>
      body{
      margin: 0;
      padding: 0;
      background: url(images/g.jpeg) no-repeat;
      
      font-family: sans-serif;
      background-size: cover;
      background-repeat: no-repeat ;
      background-position: center;
      }
      .zoom {
        overflow: hidden;
      }
      .zoom img{
        transition: transform .2s;
        margin: 0 auto;
      }
      .zoom:hover img{
        transform: scale(1.3);
      }
        .geeks {
            width: 286px;
            height: 160px;
            overflow: hidden;
            margin: 0 auto;
        }

        .geeks img {
            width:100%;
            transition: 0.5s all ease-in-out;
        }

        .geeks:hover img {
            transform:scale(1.5);   
        }
    </style>
  </head>
  <br>
  <nav class="navbar navbar-expand-lg fixed-top" style="background-color:plum">
  <div class="container-fluid text-center">
  <a class = "navbar-brand" href = "images/a.png">
  <img src = "images/a.png" width = "60" height = "60">
  </a>

    <a class="navbar-brand mb-0 h1"><strong>InstaKarya</strong></a>
    <!-- <button class="navbar-toggler" type="button" post-bs-toggle="collapse" post-bs-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation"> -->
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
</ul>
<div class="navbar-nav">
<a href="#" class="nav-link"><button type="submit" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" ><i class="fa fa-plus-square"></i></button></a>

    <a class="nav-link" href="logout.php"><button class=" btn btn-danger bi bi-box-arrow-right"></button>
</a>
      <!-- <span class="navbar-toggler-icon"></span> -->
      
</div>
</div>
</nav>  
  <!-- <center> -->
    <div class="container  mt-5">
    <?php while($post = mysqli_fetch_assoc($query)) { ?>

    <br><div class="card mx-auto mt-3" style="width: 18rem;">
    <div class="geeks">
    <img class="card-img-top" src="images/<?= $post['foto'] ?>" alt="Card image cap">
    </div>
    <div class="card-body ">
    </div>
    <ul class="list-group list-group-flush">
    <center>
    <li class="list-group-item"><strong><?= $post['caption'] ?></strong></li>
    <li class="list-group-item"><?= $post['lokasi'] ?></li>
    </center>   
    </ul>
    <div class="card-body">
      <center>
      <a href="hapus.php?no=<?=$post['no'] ?>"><i class="btn btn-danger fa fa-trash" style="font-size:24px"></i></a>
      <button type="submit" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalEdit<?=$post['no']?>" ><i class="fa fa-pencil"></i></button></a>
      </center>
    </div>
    </div>
    <br>


    </div>
    <!-- </center> -->
</body>
</html>



<!-- Modal Tambah-->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style="background-color:plum">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah InstaKarya</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        <label for="">Foto</label>
        <input type="file" name="foto" class="form-control" id="" required><br>
        <label for="">Caption</label>
        <input type="text" name="caption" class="form-control" id="" autocomplete="off"><br>
        <label for="">Lokasi</label>
        <input type="text" name="lokasi" class="form-control" id=""><br><br>
        <input type="submit" value="Simpan" name="simpan" class="btn btn-primary">
    </form>
      </div>
    </div>
  </div>
</div>


<!-- modal edit> -->
<div class="modal fade" id="modalEdit<?= $post['no']?>" tabindex="-1" aria-labelledby="modalEdit<?= $post['no']?>" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    <div class="modal-header" style="background-color:plum">
        <h1 class="modal-title fs-5" id="exampleModaltable"> Edit InstaKarya</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">
      <label for="" class="form-label">Foto</label>
    <input type="file" class="form-control" name="foto" id="" value="<?= $post['foto'] ?>" ><br>
    <img src="images/<?= $post['foto'] ?>" width="100" alt="">
    <label for="" class="form-label">Caption</label><br>
    <input type="" class="form-control" name="caption" id="" value="<?= $post['caption'] ?>" autocomplete="off"><br>
    <label for="" class="form-label">Lokasi</label><br>
    <input type="" class="form-control" name="lokasi" id=""  value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
    <input type="submit" value="Update" name="update" class="btn btn-success">
      </form>
      </div>
      </div>
    </div>
  </div>
</div>
  </div>

  <?php } ?>
  </div>

