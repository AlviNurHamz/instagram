<?php
$server  ="localhost";
$username ="root";
$password ="123456";
$database ="db_insta";
$koneksi = mysqli_connect($servrt, $username, $password, $database);


// if ($koneksi){
//     echo "terkoneksi";
// } else {
//     echo "gagal terkoneksi";
// }
?>